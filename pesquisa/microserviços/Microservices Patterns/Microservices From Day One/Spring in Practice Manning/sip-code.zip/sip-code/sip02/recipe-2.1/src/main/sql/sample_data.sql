insert into contact values
    (1, 'Zimmerman', 'Robert', 'A', 'bobdylan@example.com', null, null),
    (2, 'Osbourne', 'John', 'M', 'ozzyosbourne@example.com', null, null),
    (3, 'Mapother', 'Tom', 'C', 'tomcruise@example.com', null, null),
    (4, 'Norris', 'Carlos', 'R', 'chucknorris@example.com', null, null),
    (5, 'Johnson', 'Caryn', 'E', 'whoopigoldberg@example.com', null, null),
    (6, 'Wheeler', 'William', 'L', 'willie@foo.com', null, null),
    (7, 'Wheeler', 'John', 'M', 'john@bar.com', null, null);

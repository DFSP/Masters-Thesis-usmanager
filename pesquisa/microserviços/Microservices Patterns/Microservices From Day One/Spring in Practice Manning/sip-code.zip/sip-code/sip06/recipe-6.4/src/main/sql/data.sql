use sip06;

insert into users values
    ('juan', 'p@ssword', 1),
    ('elvira', 'p@ssword', 1);

insert into authorities values
    ('juan', 'user'),
    ('juan', 'admin'),
    ('elvira', 'user');

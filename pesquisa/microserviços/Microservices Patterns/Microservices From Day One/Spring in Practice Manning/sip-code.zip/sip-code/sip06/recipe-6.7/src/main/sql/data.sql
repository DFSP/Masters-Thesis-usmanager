use sip06;

insert into role values
    (1, 'user'),
    (2, 'admin');

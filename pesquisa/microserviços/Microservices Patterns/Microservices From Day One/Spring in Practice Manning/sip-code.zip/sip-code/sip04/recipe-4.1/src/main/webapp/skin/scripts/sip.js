$(function() {
	$("form.main :input:not(:hidden, :submit):first").focus();
});

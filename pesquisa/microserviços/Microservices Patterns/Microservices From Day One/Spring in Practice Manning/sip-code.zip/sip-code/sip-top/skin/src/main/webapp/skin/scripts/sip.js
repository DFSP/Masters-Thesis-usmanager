$(function() {
	$(".alert").hide().slideDown();
	$("form.main :input:not(:hidden, :submit):first").focus();
});
